#include "server.h"
using namespace homework;

int main()
{
    return 0;
}
